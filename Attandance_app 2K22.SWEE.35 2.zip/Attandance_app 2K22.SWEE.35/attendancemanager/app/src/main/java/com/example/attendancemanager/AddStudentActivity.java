package com.example.attendancemanager;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddStudentActivity extends AppCompatActivity {
    private EditText studentNameInput;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);

        studentNameInput = findViewById(R.id.studentNameInput);
        databaseHelper = new DatabaseHelper(this);
    }

    public void addStudent(View view) {
        String studentName = studentNameInput.getText().toString().trim();
        if (!studentName.isEmpty()) {
            databaseHelper.addStudent(studentName);
            Toast.makeText(this, "Student Added", Toast.LENGTH_SHORT).show();
            studentNameInput.setText("");
        } else {
            Toast.makeText(this, "Enter Student Name", Toast.LENGTH_SHORT).show();
        }
    }
}
