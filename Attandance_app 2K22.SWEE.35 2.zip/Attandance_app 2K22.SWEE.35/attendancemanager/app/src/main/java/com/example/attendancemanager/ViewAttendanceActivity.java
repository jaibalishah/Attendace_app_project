package com.example.attendancemanager;

import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import android.widget.ArrayAdapter;

public class ViewAttendanceActivity extends AppCompatActivity {
    private ListView attendanceListView;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_attendance);

        attendanceListView = findViewById(R.id.attendanceListView);
        databaseHelper = new DatabaseHelper(this);

        loadAttendance();
    }

    private void loadAttendance() {
        List<String> attendanceList = databaseHelper.getAttendanceRecords();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, attendanceList);
        attendanceListView.setAdapter(adapter);
    }
}
