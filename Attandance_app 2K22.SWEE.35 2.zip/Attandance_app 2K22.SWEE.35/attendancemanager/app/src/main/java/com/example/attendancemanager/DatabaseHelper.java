package com.example.attendancemanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "AttendanceManager.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_STUDENTS = "students";
    private static final String TABLE_ATTENDANCE = "attendance";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_STUDENTS + " (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_ATTENDANCE + " (id INTEGER PRIMARY KEY AUTOINCREMENT, studentName TEXT, date TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ATTENDANCE);
        onCreate(db);
    }

    public void addStudent(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        db.insert(TABLE_STUDENTS, null, values);
        db.close();
    }

    public List<String> getAllStudents() {
        List<String> students = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT name FROM " + TABLE_STUDENTS, null);
        if (cursor.moveToFirst()) {
            do {
                students.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return students;
    }

    public void markAttendance(String studentName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("studentName", studentName);
        values.put("date", System.currentTimeMillis());
        db.insert(TABLE_ATTENDANCE, null, values);
        db.close();
    }

    public List<String> getAttendanceRecords() {
        List<String> attendance = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT studentName, date FROM " + TABLE_ATTENDANCE, null);
        if (cursor.moveToFirst()) {
            do {
                attendance.add(cursor.getString(0) + " - " + cursor.getString(1));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return attendance;
    }
}
