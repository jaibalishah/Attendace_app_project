package com.example.attendancemanager;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MarkAttendanceActivity extends AppCompatActivity {
    private ListView studentListView;
    private DatabaseHelper databaseHelper;
    private List<String> studentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mark_attendance);

        studentListView = findViewById(R.id.studentListView);
        databaseHelper = new DatabaseHelper(this);

        loadStudents();
    }

    private void loadStudents() {
        studentList = databaseHelper.getAllStudents();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_multiple_choice, studentList);
        studentListView.setAdapter(adapter);
    }

    public void markAttendance(View view) {
        for (int i = 0; i < studentListView.getCount(); i++) {
            if (studentListView.isItemChecked(i)) {
                databaseHelper.markAttendance(studentList.get(i));
            }
        }
        Toast.makeText(this, "Attendance Marked", Toast.LENGTH_SHORT).show();
    }
}
